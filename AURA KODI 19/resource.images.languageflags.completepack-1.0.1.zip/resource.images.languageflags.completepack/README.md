Language flags complete pack
=================

This add-on contains all of the language flags Kodi needs.

All of the Kodi supported languages have been taken into account and if there's a flag and a code for it it's in here.

I used https://en.wikipedia.org/wiki/List_of_ISO_639-2_codes as a reference for the codes.

Ronie helped out a lot by explaining the codes and what's happening behind the scenes in Kodi (conversion from one code to another, etc).
